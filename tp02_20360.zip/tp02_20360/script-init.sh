# Extract the initial directories
  cd ..
  unzip "lego dataset.zip" -d tp02_20360/primeira
  unzip "tp02_20360.zip"
  cd tp02_20360
  unzip "*.zip"
# Create 11 directories using the information in the sets.tsv file
  cd primeira
  # Set the counter to 0
    count=0
  # Read the file line by line
  while read -r line; do
  # Split the line into columns using the tab character as the delimiter
  # Assign the columns to variables
    col1=$(echo "$line" | cut -f1 -d$'\t')
    col2=$(echo "$line" | cut -f2 -d$'\t')
    col3=$(echo "$line" | cut -f3 -d$'\t')
    col4=$(echo "$line" | cut -f4 -d$'\t')
  # Check if the directory for col4 exists, and create it if it doesn't
    if [ ! -d "$col4" ]; then
      mkdir "$col4"
      # Increment the counter
        ((count++))
    fi
  # Check if the counter is greater than 11
    if [ "$count" -gt 11 ]; then
      # If it is, exit the loop
      break
    fi
  # Create the directory for col3 within the col4 directory
    mkdir "$col4/$col3"
    mkdir "$col4/$col3/$col2"
    mkdir "$col4/$col3/$col2/$col1"
done < sets.tsv
# Delete the title folder
  rm -r theme
# Move all themes to the themes folder
  # Delete the "themes" directory if it exists
    if [ -d "themes" ]; then
      rm -r themes
    fi
  # Create the "themes" directory
    mkdir themes
  # Move all the existing directories into the "themes" directory
    for dir in */; do
      mv "$dir" themes/
    done
