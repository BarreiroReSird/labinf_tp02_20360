#!/bin/bash

SET_NUM=""
PART_SET_NUM=""
PART_NUM=""
CURRENT_PART_NUM=""
currentDirname=$(pwd)

# Go to the correct directory
cd primeira

# Read each line of parts_sets.tsv
setLineIndex=0
while IFS= read -r setLine; do
  setLineIndex=$((setLineIndex+1))
  if [ $setLineIndex -eq 1 ]; then
    continue
  fi
  IFS=$'\t' read -ra setLineColumns <<< "$setLine"
  if test -d "$currentDirname/primeira/themes/${setLineColumns[3]}/${setLineColumns[2]}/${setLineColumns[1]}/${setLineColumns[0]}"; then
    touch "$currentDirname/primeira/themes/${setLineColumns[3]}/${setLineColumns[2]}/${setLineColumns[1]}/${setLineColumns[0]}/parts.txt"
  fi

  SET_NUM=${setLineColumns[0]}
  while IFS= read -r partSetLine; do
    IFS=$'\t' read -ra partSetLineColumns <<< "$partSetLine"

    echo "Searching for part set correspondence by set $SET_NUM"
    PART_SET_NUM=${partSetLineColumns[0]}
    PART_NUM=${partSetLineColumns[2]}

    if [[ "$SET_NUM" = "$PART_SET_NUM" ]]; then
      echo "Found set $SET_NUM. Searching for part with number $PART_NUM"
      while IFS= read -r partLine; do
        IFS=$'\t' read -ra partLineColumns <<< "$partLine"
        
        CURRENT_PART_NUM=${partLineColumns[0]}

        if [ $CURRENT_PART_NUM == "$PART_NUM" ]; then
          echo -e "$CURRENT_PART_NUM | ${partLineColumns[1]}  | ${partLineColumns[2]}  | ${partLineColumns[3]} | ${partSetLineColumns[1]}" >> "$currentDirname/primeira/themes/${setLineColumns[3]}/${setLineColumns[2]}/${setLineColumns[1]}/${setLineColumns[0]}/parts.txt"
          break
        fi
      done < parts.tsv
    fi
  done < parts_sets.tsv
done < sets.tsv
