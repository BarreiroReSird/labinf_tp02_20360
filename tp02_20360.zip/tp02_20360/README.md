# Trabalho de Laboratórios de Informática

## Localização

A localização de ambos os ficheiro, "tp02_20360.zip" e "lego dataset", será no Desktop (Ambiente de trabalho)

## Modo de abertura

Para abrir o ficheiro, começar por executar o ficheiro "script-init.sh" ou escrever no terminal "bash script-init.sh", após o "script-init.sh" acabar, executar o ficheiro "script.sh" ou escrever no terminal "bash script.sh".